﻿# Update NAC apps - downloads the newest versions from GitHub and updates every NAC app on this PC
$ErrorActionPreference = 'Stop'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}
$Site = 'https://infinitytimetable.github.io/NAC-Music-Hub/'
$Dl   = $Site + 'downloads/'
$Apps = @(
  @{ Name = 'NAC Music Hub';         Zip = 'NAC_Music_Hub_PC.zip' },
  @{ Name = 'NAC Programme Studio';  Zip = 'NAC_Programme_Studio_PC.zip' },
  @{ Name = 'NAC Service Projector'; Zip = 'NAC_Service_Projector_PC.zip' },
  @{ Name = 'NAC Choir Rehearsal';   Zip = 'NAC_Choir_Rehearsal_PC.zip' })
function Ver($v) { $p = ("$v" -replace '[^0-9.]', '').Split('.') + @('0','0','0'); return [int]$p[0] * 1000000 + [int]$p[1] * 1000 + [int]$p[2] }
Write-Host ''
Write-Host '  ==================================================' -ForegroundColor Cyan
Write-Host '     Update NAC apps' -ForegroundColor Cyan
Write-Host '  ==================================================' -ForegroundColor Cyan
Write-Host ''
Write-Host '  Checking for a new version...'
try { $info = Invoke-RestMethod -Uri ($Site + 'version.json?t=' + [DateTime]::Now.Ticks) -UseBasicParsing -TimeoutSec 30 }
catch { Write-Host '  Could not reach the internet (or GitHub). Check the connection and try again.' -ForegroundColor Red; Read-Host '  Press Enter to close'; exit 1 }
$latest = "$($info.version)"
Write-Host "  Newest version: $latest" -ForegroundColor Green
if ($info.notes) { foreach ($n in $info.notes) { Write-Host "    - $n" } }
Write-Host ''
$todo = @()
foreach ($a in $Apps) {
  $dir = Join-Path $env:LOCALAPPDATA $a.Name; $vf = Join-Path $dir 'version.txt'
  if (-not (Test-Path $dir)) { continue }
  $have = if (Test-Path $vf) { (Get-Content $vf -Raw).Trim() } else { '0' }
  if ((Ver $latest) -gt (Ver $have)) { Write-Host "  $($a.Name): v$have  ->  v$latest"; $todo += $a } else { Write-Host "  $($a.Name): v$have  (up to date)" -ForegroundColor DarkGray }
}
if (-not $todo.Count) { Write-Host ''; Write-Host '  Everything is up to date.' -ForegroundColor Green; Read-Host '  Press Enter to close'; exit 0 }
Write-Host ''
$ok = Read-Host '  Update now? Your programmes, hymns, choir records and settings are kept. (Y/N, default Y)'
if ($ok -and $ok.Trim().ToUpper() -ne 'Y') { Write-Host '  Nothing was changed.'; exit 0 }
$tmp = Join-Path $env:TEMP ('nac-update-' + [Guid]::NewGuid().ToString('N').Substring(0, 8))
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
$done = 0
foreach ($a in $todo) {
  Write-Host ''
  Write-Host "  Downloading $($a.Name) (about 50 MB, please wait)..." -ForegroundColor Cyan
  $zip = Join-Path $tmp $a.Zip
  try {
    $old = $ProgressPreference; $ProgressPreference = 'SilentlyContinue'
    Invoke-WebRequest -Uri ($Dl + $a.Zip) -OutFile $zip -UseBasicParsing -TimeoutSec 1800
    $ProgressPreference = $old
  } catch { Write-Host "  Download failed: $($_.Exception.Message)" -ForegroundColor Red; continue }
  $x = Join-Path $tmp ($a.Zip -replace '\.zip$', '')
  Expand-Archive -Path $zip -DestinationPath $x -Force
  try { Get-ChildItem $x -Recurse -File | Unblock-File } catch {}
  $setup = Get-ChildItem $x -Recurse -Filter 'install.ps1' | Where-Object { $_.Directory.Name -eq 'setup' } | Select-Object -First 1
  if (-not $setup) { Write-Host '  The download did not contain the installer.' -ForegroundColor Red; continue }
  & powershell -NoProfile -ExecutionPolicy Bypass -File $setup.FullName -AutoUpdate -NoOpen
  if ($LASTEXITCODE -eq 0 -or $LASTEXITCODE -eq $null) { $done++ }
}
Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
Write-Host ''
if ($done -eq $todo.Count) { Write-Host "  Done! Updated to v$latest. Open the app as usual." -ForegroundColor Green }
else { Write-Host "  $done of $($todo.Count) apps updated. Try again later, or download the installer from infinitytimetable.github.io/NAC-Music-Hub" -ForegroundColor Yellow }
Read-Host '  Press Enter to close'
