﻿# NAC Programme Studio - put back the data saved before an update
$AppName = 'NAC Programme Studio'
$Dest = Join-Path $env:LOCALAPPDATA $AppName
$Files = Join-Path ([Environment]::GetFolderPath('MyDocuments')) $AppName
Write-Host ''
Write-Host "  $AppName - restore data from before an update" -ForegroundColor Cyan
Write-Host '  (Tip: inside the app, Settings > Restore from a backup can also restore the weekly backups.)'
Write-Host ''
$list = @(Get-ChildItem (Join-Path $Files 'Backups') -Directory -Filter 'Before update *' -ErrorAction SilentlyContinue | Sort-Object Name -Descending)
if (-not $list.Count) { Write-Host '  No backups from updates were found.' -ForegroundColor Yellow; Start-Sleep 4; exit }
for ($i = 0; $i -lt $list.Count; $i++) { Write-Host ("    {0} = {1}" -f ($i + 1), $list[$i].Name) }
$a = Read-Host '  Type the number to restore (or press Enter to cancel)'
if (-not $a) { exit }
$pick = $list[[int]$a - 1]; if (-not $pick) { exit }
$ok = Read-Host "  This replaces the app's current data with the data from '$($pick.Name)'. Continue? (Y/N)"
if ($ok.Trim().ToUpper() -ne 'Y') { exit }
Get-CimInstance Win32_Process -Filter "Name='chrome.exe' OR Name='msedge.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like "*$Dest*" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep 2
Get-ChildItem $pick.FullName -Directory | ForEach-Object {
  foreach ($part in 'Default\IndexedDB', 'Default\Local Storage', 'Default\File System') {
    $from = Join-Path $_.FullName $part; $to = Join-Path (Join-Path $Dest $_.Name) $part
    if (Test-Path $from) { if (Test-Path $to) { Remove-Item $to -Recurse -Force }; New-Item -ItemType Directory -Force -Path (Split-Path $to) | Out-Null; Copy-Item $from $to -Recurse -Force }
  }
}
Write-Host '  Done - open the app again.' -ForegroundColor Green
Start-Sleep 4
