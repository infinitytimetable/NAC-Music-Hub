﻿# NAC Choir Rehearsal - uninstaller (your data is kept unless you choose to delete it)
$AppName = 'NAC Choir Rehearsal'
$Dest = Join-Path $env:LOCALAPPDATA $AppName
Write-Host ''
Write-Host "  $AppName - Uninstall" -ForegroundColor Cyan
Write-Host ''
$ok = Read-Host "  Remove $AppName from this PC? (Y/N)"
if (-not $ok -or $ok.Trim().ToUpper() -ne 'Y') { Write-Host '  Cancelled.'; Start-Sleep 2; exit }
Get-CimInstance Win32_Process -Filter "Name='chrome.exe' OR Name='msedge.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like "*$Dest*" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Remove-Item (Join-Path ([Environment]::GetFolderPath('Desktop')) "$AppName.lnk") -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path ([Environment]::GetFolderPath('Programs')) $AppName) -Recurse -Force -ErrorAction SilentlyContinue
Write-Host ''
Write-Host '  Your saved programmes, hymns, choir records and settings are KEPT,' -ForegroundColor Yellow
Write-Host '  so installing the app again later brings them back.' -ForegroundColor Yellow
$del = Read-Host '  To DELETE all saved data as well, type DELETE (or just press Enter to keep it)'
if ($del -and $del.Trim().ToUpper() -eq 'DELETE') {
  $sure = Read-Host '  Are you sure? This cannot be undone (Y/N)'
  if ($sure.Trim().ToUpper() -eq 'Y') { Start-Sleep 1; Remove-Item $Dest -Recurse -Force -ErrorAction SilentlyContinue; Write-Host "  Removed $AppName and its data." -ForegroundColor Green; Start-Sleep 3; exit }
}
Get-ChildItem $Dest -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -notin 'browser.txt', 'version.txt', 'last-backup.txt' } | Remove-Item -Force -ErrorAction SilentlyContinue
Write-Host "  Removed $AppName. Your data was kept in: $Dest" -ForegroundColor Green
Start-Sleep 3
