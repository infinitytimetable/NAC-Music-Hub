﻿# NAC Music Hub - installer and updater (version 1.9.6)
param([string]$Browser = '', [switch]$NoOpen, [switch]$AutoUpdate)
$ErrorActionPreference = 'Stop'
$AppName = 'NAC Music Hub'
$Version = '1.9.6'
$HtmlName = 'NAC_Music_Hub.html'
$Src     = Split-Path -Parent $MyInvocation.MyCommand.Path
$Dest    = Join-Path $env:LOCALAPPDATA $AppName
$Html    = Join-Path $Dest $HtmlName
$Icon    = Join-Path $Dest 'icon.ico'
$Docs    = [Environment]::GetFolderPath('MyDocuments')
$Files   = Join-Path $Docs $AppName

function Find-Browser($exe, $paths) {
  foreach ($p in $paths) { if ($p -and (Test-Path $p)) { return $p } }
  foreach ($hive in 'HKCU:', 'HKLM:') {
    $k = "$hive\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\$exe"
    try { $v = (Get-ItemProperty -Path $k -ErrorAction Stop).'(default)'; if ($v -and (Test-Path $v)) { return $v } } catch {}
  }
  return $null
}
function App-Running { Get-CimInstance Win32_Process -Filter "Name='chrome.exe' OR Name='msedge.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like "*$Dest*" } }

Write-Host ''
Write-Host '  ==================================================' -ForegroundColor Cyan
Write-Host "     $AppName  -  Installer  (v$Version)" -ForegroundColor Cyan
Write-Host '  ==================================================' -ForegroundColor Cyan
Write-Host ''

# ---------- is an older version already installed? ----------
$installed = Test-Path $Html
$oldVer = ''
if ($installed) {
  $vf = Join-Path $Dest 'version.txt'
  if (Test-Path $vf) { $oldVer = (Get-Content $vf -Raw).Trim() }
  else { try { $m = Select-String -Path $Html -Pattern 'version (1\.[0-9]+)' -List; if ($m) { $oldVer = $m.Matches[0].Groups[1].Value } } catch {} }
  if (-not $oldVer) { $oldVer = 'an earlier version' } else { $oldVer = "v$oldVer" }
}
$mode = 'install'
if ($installed) {
  if ($AutoUpdate) { $mode = 'update' }
  else {
    Write-Host "  $AppName $oldVer is installed on this PC." -ForegroundColor Yellow
    Write-Host "  What would you like to do?"
    Write-Host "    1 = UPDATE to v$Version and keep everything  (recommended)"
    Write-Host "        your programmes, hymns, choir, settings and save folder are kept"
    Write-Host "    2 = FRESH INSTALL  (starts empty - your old data is backed up first)"
    Write-Host "    3 = Cancel"
    $a = Read-Host '  Type 1, 2 or 3 and press Enter (default 1)'
    if (-not $a) { $a = '1' }
    switch ($a.Trim()) { '2' { $mode = 'fresh' } '3' { Write-Host '  Cancelled - nothing was changed.'; exit 0 } default { $mode = 'update' } }
    if ($mode -eq 'fresh') {
      Write-Host ''
      Write-Host '  A fresh install removes all saved programmes, hymn edits, choir records and settings.' -ForegroundColor Red
      $c1 = Read-Host '  Are you sure? Type YES to continue'
      if ($c1.Trim().ToUpper() -ne 'YES') { Write-Host '  Cancelled - nothing was changed.'; exit 0 }
      $c2 = Read-Host '  Really start empty? (Y/N)'
      if ($c2.Trim().ToUpper() -ne 'Y') { Write-Host '  Cancelled - nothing was changed.'; exit 0 }
    }
  }
}

# ---------- close the app if it is open ----------
if ($installed -and (App-Running)) {
  Write-Host ''
  Write-Host "  $AppName is open. Please close it so nothing is lost while it saves." -ForegroundColor Yellow
  for ($i = 0; $i -lt 30 -and (App-Running); $i++) {
    $r = Read-Host '  Close the app window, then press Enter  (or type C to close it for you)'
    if ($r -and $r.Trim().ToUpper() -eq 'C') { Start-Sleep 1; App-Running | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }; Start-Sleep 2 }
  }
}

# ---------- browser ----------
$chrome = Find-Browser 'chrome.exe' @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")
$edge = Find-Browser 'msedge.exe' @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe")
if (-not $chrome -and -not $edge) { Write-Host '  Google Chrome or Microsoft Edge was not found on this PC. Install one of them, then run Install.bat again.' -ForegroundColor Red; exit 1 }
$choiceFile = Join-Path $Dest 'browser.txt'
$last = if (Test-Path $choiceFile) { (Get-Content $choiceFile -Raw).Trim() } else { '' }
$name = $null
if ($Browser -eq 'Chrome' -and $chrome) { $name = 'Chrome' } elseif ($Browser -eq 'Edge' -and $edge) { $name = 'Edge' }
elseif ($mode -eq 'update' -and $last -and (($last -eq 'Chrome' -and $chrome) -or ($last -eq 'Edge' -and $edge))) { $name = $last }
elseif ($chrome -and $edge) {
  $def = if ($last -eq 'Edge') { '2' } else { '1' }
  Write-Host ''
  Write-Host '  Which browser should run the app?   1 = Google Chrome    2 = Microsoft Edge'
  $a = Read-Host "  Type 1 or 2 and press Enter (default $def)"
  if (-not $a) { $a = $def }
  $name = if ($a.Trim() -eq '2') { 'Edge' } else { 'Chrome' }
} elseif ($chrome) { $name = 'Chrome' } else { $name = 'Edge' }
$browserExe = if ($name -eq 'Edge') { $edge } else { $chrome }
if ($last -and $last -ne $name) { Write-Host "  NOTE: the app was used with $last before. To move your data: Settings > Backup in $last, then Restore in $name." -ForegroundColor Yellow }

# ---------- back up the saved data before changing anything ----------
New-Item -ItemType Directory -Force -Path $Files | Out-Null
if ($installed) {
  $stamp = Get-Date -Format 'yyyy-MM-dd HH-mm'
  $bk = Join-Path $Files "Backups\Before update $stamp"
  $n = 0
  Get-ChildItem $Dest -Directory -Filter 'Data-*' -ErrorAction SilentlyContinue | ForEach-Object {
    foreach ($part in 'Default\IndexedDB', 'Default\Local Storage', 'Default\File System') {
      $from = Join-Path $_.FullName $part
      if (Test-Path $from) { $to = Join-Path $bk (Join-Path $_.Name $part); New-Item -ItemType Directory -Force -Path (Split-Path $to) | Out-Null; Copy-Item $from $to -Recurse -Force -ErrorAction SilentlyContinue; $n++ }
    }
  }
  if ($n) { Write-Host "  Backup of your data saved in: $bk" -ForegroundColor Green; Set-Content -Path (Join-Path $Dest 'last-backup.txt') -Value $bk -Encoding UTF8 }
  if ($mode -eq 'fresh') { Get-ChildItem $Dest -Directory -Filter 'Data-*' | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue; Write-Host '  Old data removed (the backup above is kept).' }
}

Write-Host ''
Write-Host $(if ($mode -eq 'update') { "  Updating to v$Version with $name ..." } else { "  Installing with $name ..." })
New-Item -ItemType Directory -Force -Path $Dest | Out-Null
Copy-Item (Join-Path $Src $HtmlName) $Html -Force
Copy-Item (Join-Path $Src 'icon.ico') $Icon -Force
foreach ($f in 'uninstall.ps1', 'restore.ps1') { Copy-Item (Join-Path $Src $f) (Join-Path $Dest $f) -Force }
Set-Content -Path $choiceFile -Value $name -Encoding ASCII
Set-Content -Path (Join-Path $Dest 'version.txt') -Value $Version -Encoding ASCII
try { Get-ChildItem $Dest -File | Unblock-File } catch {}

$DataDir = Join-Path $Dest "Data-$name"
New-Item -ItemType Directory -Force -Path $DataDir | Out-Null
$Url  = ([System.Uri]$Html).AbsoluteUri
$LaunchArgs = "--app=`"$Url`" --user-data-dir=`"$DataDir`" --no-first-run --no-default-browser-check --autoplay-policy=no-user-gesture-required --start-maximized"

$ws = New-Object -ComObject WScript.Shell
function Make-Shortcut($path) { $s = $ws.CreateShortcut($path); $s.TargetPath = $browserExe; $s.Arguments = $LaunchArgs; $s.WorkingDirectory = $Dest; $s.IconLocation = "$Icon,0"; $s.Description = $AppName; $s.Save() }
$desktop = [Environment]::GetFolderPath('Desktop')
$menu    = Join-Path ([Environment]::GetFolderPath('Programs')) $AppName
New-Item -ItemType Directory -Force -Path $menu | Out-Null
Make-Shortcut (Join-Path $desktop "$AppName.lnk")
Make-Shortcut (Join-Path $menu "$AppName.lnk")
$ps = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$u = $ws.CreateShortcut((Join-Path $menu "Uninstall $AppName.lnk")); $u.TargetPath = $ps; $u.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $Dest 'uninstall.ps1')`""; $u.IconLocation = "$Icon,0"; $u.Save()
$r = $ws.CreateShortcut((Join-Path $menu "Restore data from before an update.lnk")); $r.TargetPath = $ps; $r.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $Dest 'restore.ps1')`""; $r.IconLocation = "$Icon,0"; $r.Save()
$f = $ws.CreateShortcut((Join-Path $desktop "$AppName files.lnk")); $f.TargetPath = $Files; $f.IconLocation = "$env:SystemRoot\System32\shell32.dll,3"; $f.Save()
# ---------- one updater for all NAC apps (downloads new versions from GitHub) ----------
$UpDir = Join-Path $env:LOCALAPPDATA 'NAC Music Updater'
New-Item -ItemType Directory -Force -Path $UpDir | Out-Null
if (Test-Path (Join-Path $Src 'update.ps1')) { Copy-Item (Join-Path $Src 'update.ps1') (Join-Path $UpDir 'update.ps1') -Force }
$upMenu = Join-Path ([Environment]::GetFolderPath('Programs')) 'NAC Music apps'
New-Item -ItemType Directory -Force -Path $upMenu | Out-Null
foreach ($lnk in (Join-Path $desktop 'Update NAC apps.lnk'), (Join-Path $upMenu 'Update NAC apps.lnk')) {
  $x = $ws.CreateShortcut($lnk); $x.TargetPath = $ps; $x.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $UpDir 'update.ps1')`""; $x.WorkingDirectory = $UpDir; $x.IconLocation = "$env:SystemRoot\System32\shell32.dll,238"; $x.Description = 'Download and install the newest NAC apps'; $x.Save()
}

Write-Host ''
if ($mode -eq 'update') { Write-Host "  Done! $AppName is updated to v$Version. Everything you saved is still there." -ForegroundColor Green }
else { Write-Host "  Done! `"$AppName`" is on your Desktop and in the Start menu." -ForegroundColor Green }
Write-Host "  Your files folder: $Files"
Write-Host ''
if (-not $NoOpen) { $open = Read-Host '  Open it now? (Y/N, default Y)'; if (-not $open -or $open.Trim().ToUpper() -eq 'Y') { Start-Process -FilePath $browserExe -ArgumentList $LaunchArgs } }
