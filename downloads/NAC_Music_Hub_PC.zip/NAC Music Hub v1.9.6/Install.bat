@echo off
title NAC Music Hub - Install or update
if not exist "%~dp0setup\install.ps1" (
  echo.
  echo  Please EXTRACT the zip first: right-click it and choose "Extract All",
  echo  then open the extracted folder and double-click Install.bat again.
  echo.
  pause
  exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup\install.ps1"
echo.
pause
